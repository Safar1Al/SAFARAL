package com.safar50.app.ui.theme

import androidx.compose.ui.graphics.Color

val DeepSpace = Color(0xFF0B0F2E)
val RoyalViolet = Color(0xFF5B2A86)
val ElectricTeal = Color(0xFF00D9C0)
val SunsetCoral = Color(0xFFFF6B6B)
val GoldAccent = Color(0xFFFFC857)
val GlassWhite = Color(0x33FFFFFF)
val GlassBorder = Color(0x55FFFFFF)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xB3FFFFFF)
