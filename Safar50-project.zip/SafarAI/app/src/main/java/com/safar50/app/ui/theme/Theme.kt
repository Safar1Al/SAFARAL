package com.safar50.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val SafarAIColorScheme = darkColorScheme(
    primary = ElectricTeal,
    secondary = SunsetCoral,
    tertiary = GoldAccent,
    background = DeepSpace,
    surface = RoyalViolet,
    onPrimary = DeepSpace,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun SafarAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SafarAIColorScheme,
        typography = MaterialTheme.typography.copy(
            headlineMedium = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            titleLarge = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold)
        ),
        content = content
    )
}
