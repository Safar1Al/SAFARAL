package com.safar50.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.safar50.app.R
import com.safar50.app.ui.theme.*

@Composable
fun HomeScreen(onServiceClick: (ServiceRoute) -> Unit) {
    AuroraBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(48.dp))

            Text(
                text = stringResource(R.string.app_name),
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = stringResource(R.string.tagline),
                color = TextSecondary,
                fontSize = 14.sp
            )

            Spacer(Modifier.height(20.dp))

            // Search bar (glass pill)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .glassCard(28)
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = TextSecondary)
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.search_hint), color = TextSecondary, fontSize = 14.sp)
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = stringResource(R.string.home_greeting),
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(Modifier.height(12.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(services) { service ->
                    ServiceCard(service = service, onClick = { onServiceClick(service.route) })
                }
            }

            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ServiceCard(service: ServiceItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .glassCard(20)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(GlassBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(service.icon, contentDescription = null, tint = ElectricTeal)
        }
        Column {
            Text(
                text = stringResource(service.titleRes),
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = stringResource(service.descRes),
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 2
            )
        }
    }
}
