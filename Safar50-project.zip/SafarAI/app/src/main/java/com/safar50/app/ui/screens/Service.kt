package com.safar50.app.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DirectionsBoat
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.ui.graphics.vector.ImageVector
import com.safar50.app.R

enum class ServiceRoute { FLIGHTS, HOTELS, TRAINS_SHIPS, TAXI, CALLS, TRANSLATOR, VISA, CLIMATE }

data class ServiceItem(
    val route: ServiceRoute,
    val titleRes: Int,
    val descRes: Int,
    val icon: ImageVector
)

val services = listOf(
    ServiceItem(ServiceRoute.FLIGHTS, R.string.service_flights, R.string.service_flights_desc, Icons.Filled.AirplanemodeActive),
    ServiceItem(ServiceRoute.HOTELS, R.string.service_hotels, R.string.service_hotels_desc, Icons.Filled.Hotel),
    ServiceItem(ServiceRoute.TRAINS_SHIPS, R.string.service_trains_ships, R.string.service_trains_ships_desc, Icons.Filled.DirectionsBoat),
    ServiceItem(ServiceRoute.TAXI, R.string.service_taxi, R.string.service_taxi_desc, Icons.Filled.LocalTaxi),
    ServiceItem(ServiceRoute.CALLS, R.string.service_calls, R.string.service_calls_desc, Icons.Filled.Call),
    ServiceItem(ServiceRoute.TRANSLATOR, R.string.service_translator, R.string.service_translator_desc, Icons.Filled.Translate),
    ServiceItem(ServiceRoute.VISA, R.string.service_visa, R.string.service_visa_desc, Icons.Filled.Public),
    ServiceItem(ServiceRoute.CLIMATE, R.string.service_climate, R.string.service_climate_desc, Icons.Filled.WbSunny)
)
