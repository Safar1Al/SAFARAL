package com.safar50.app.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp

/**
 * Deep-space aurora gradient used behind every screen so the glass
 * cards floating on top have something colourful to refract.
 */
@Composable
fun AuroraBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(DeepSpace, RoyalViolet, DeepSpace),
                    start = Offset(0f, 0f),
                    end = Offset(1000f, 1400f)
                )
            )
    ) {
        // Soft glow blobs
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(ElectricTeal.copy(alpha = 0.25f), androidx.compose.ui.graphics.Color.Transparent),
                        center = Offset(150f, 250f),
                        radius = 800f
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(SunsetCoral.copy(alpha = 0.20f), androidx.compose.ui.graphics.Color.Transparent),
                        center = Offset(900f, 1600f),
                        radius = 900f
                    )
                )
        )
        content()
    }
}

/** A frosted-glass card: translucent fill + subtle border + rounded corners. */
fun Modifier.glassCard(cornerRadius: Int = 24): Modifier = this
    .clip(RoundedCornerShape(cornerRadius.dp))
    .background(GlassWhite)
    .border(1.dp, GlassBorder, RoundedCornerShape(cornerRadius.dp))
