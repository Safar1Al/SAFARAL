package com.safar50.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.safar50.app.ui.screens.HomeScreen
import com.safar50.app.ui.screens.ServiceDetailScreen
import com.safar50.app.ui.screens.services
import com.safar50.app.ui.theme.SafarAITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SafarAITheme {
                SafarAIApp()
            }
        }
    }
}

@Composable
fun SafarAIApp() {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(onServiceClick = { route ->
                navController.navigate("service/${route.name}")
            })
        }
        composable("service/{routeName}") { backStackEntry ->
            val routeName = backStackEntry.arguments?.getString("routeName")
            val service = services.firstOrNull { it.route.name == routeName } ?: services.first()
            ServiceDetailScreen(service = service, onBack = { navController.popBackStack() })
        }
    }
}
